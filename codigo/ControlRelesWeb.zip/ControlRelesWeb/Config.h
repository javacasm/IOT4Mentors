#ifndef _CONFIG_H_
#define _CONFIG_H_


#define ARDUINO_HOSTNAME "OTA-wemos-caldera"
char* ssid = "jazzBajo";
//char* ssid = "CEP_MONTILLA-UNIFI";
//char* password = "CEPMONTILLA";
char* password = "qazxcvbgtrewsdf";

#endif
