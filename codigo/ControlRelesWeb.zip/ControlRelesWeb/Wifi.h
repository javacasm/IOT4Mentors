#ifndef _WIFI_H_
#define _WIFI_H_


void setup_Wifi();

void loop_wifi();

#endif
