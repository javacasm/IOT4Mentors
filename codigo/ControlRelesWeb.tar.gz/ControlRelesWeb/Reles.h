
#define RELE_1 D1
#define RELE_2 D4


void setup_reles();
void apagaRele(int pinRele);
void enciendeRele(int pinRele);
